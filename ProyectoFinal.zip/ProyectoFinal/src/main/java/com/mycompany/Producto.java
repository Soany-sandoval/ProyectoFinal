/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany;

/**
 *
 * @author usuario
 */
public class Producto {
    
}
// Clase Producto
class Producto {
    private String nombre;
    private int cantidad;
    private double precio;
    private Categoria categoria;
    private Proveedor proveedor;

    public Producto(String nombre, int cantidad, double precio, Categoria categoria, Proveedor proveedor) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.categoria = categoria;
        this.proveedor = proveedor;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    // Método para verificar si el stock es bajo
    public boolean isStockBajo(int umbral) {
        return cantidad < umbral;
    }
}