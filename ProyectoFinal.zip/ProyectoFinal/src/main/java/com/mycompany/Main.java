/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany;

/**
 *
 * @author usuario
 */
public class Main {
    
}
// Clase principal para interacción con el usuario
public class SistemaInventario {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventario inventario = new Inventario();

        while (true) {
            System.out.println("\n--- Menú del Sistema de Gestión de Inventarios ---");
            System.out.println("1. Agregar Producto");
            System.out.println("2. Mostrar Productos");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            if (opcion == 1) {
                // Agregar producto
                System.out.print("Nombre del Producto: ");
                String nombre = scanner.nextLine();
                System.out.print("Cantidad: ");
                int cantidad = scanner.nextInt();
                System.out.print("Precio: ");
                double precio = scanner.nextDouble();
                scanner.nextLine(); // Limpiar buffer

                // Agregar categoría y proveedor
                System.out.print("Nombre de la Categoría: ");
                String categoriaNombre = scanner.nextLine();
                Categoria categoria = new Categoria(categoriaNombre);

                System.out.print("Nombre del Proveedor: ");
                String proveedorNombre = scanner.nextLine();
                System.out.print("Contacto del Proveedor: ");
                String proveedorContacto = scanner.nextLine();
                Proveedor proveedor = new Proveedor(proveedorNombre, proveedorContacto);

                // Crear y agregar el producto al inventario
                Producto producto = new Producto(nombre, cantidad, precio, categoria, proveedor);
                inventario.agregarProducto(producto);
                
            } else if (opcion == 2) {
                // Mostrar productos
                inventario.mostrarProductos();
                
            } else if (opcion == 3) {
                // Salir del programa
                System.out.println("Saliendo del sistema...");
                break;

            } else {
                System.out.println("Opción no válida. Por favor intente nuevamente.");
            }
        }
        
        scanner.close();
    }
}