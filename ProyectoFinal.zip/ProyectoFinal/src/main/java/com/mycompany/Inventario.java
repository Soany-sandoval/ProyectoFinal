/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany;

/**
 *
 * @author usuario
 */
public class Inventario {
    
}
// Clase Inventario
class Inventario {
    private List<Producto> productos;

    public Inventario() {
        this.productos = new ArrayList<>();
    }

    // Método para agregar un producto al inventario
    public void agregarProducto(Producto producto) {
        productos.add(producto);
        System.out.println("Producto agregado: " + producto.getNombre());
    }

    // Método para mostrar todos los productos en el inventario
    public void mostrarProductos() {
        System.out.println("\n--- Productos en Inventario ---");
        for (Producto p : productos) {
            System.out.println("- " + p.getNombre() + " | Cantidad: " + p.getCantidad() + " | Precio: $" + p.getPrecio());
            if (p.isStockBajo(5)) { // Umbral de stock bajo
                System.out.println("  ¡Alerta! Stock bajo para " + p.getNombre());
            }
        }
        if (productos.isEmpty()) {
            System.out.println("No hay productos en el inventario.");
        }
    }
}